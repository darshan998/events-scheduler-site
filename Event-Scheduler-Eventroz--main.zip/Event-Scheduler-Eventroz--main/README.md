# Event-Scheduler-Eventroz-
An event scheduler site where users can register for an event as well as publish about the event they are hosting

The admin panel has the name of EMS[Event Management system] and the wesite is named as Eventroz.

2. To login as admin use
      username: admin
      password: Test@123

3. Running the project
a. Download the zip file

b. Extract the file 

c.Paste inside root directory(for xampp xampp/htdocs)

d. Open PHPMyAdmin (http://localhost/phpmyadmin)

e. Create a database with name eventroz (case-sensitive)

f. Import eventroz.sql file(given inside the zip package in SQL file folder)
